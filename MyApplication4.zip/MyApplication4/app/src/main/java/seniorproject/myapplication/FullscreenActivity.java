package seniorproject.myapplication;

        import android.accounts.Account;
        import android.os.AsyncTask;
        import android.os.RemoteException;
        import android.os.Bundle;
        import android.support.v7.app.AppCompatActivity;
        import android.widget.*;

        import com.clover.sdk.util.CloverAccount;
        import com.clover.sdk.v1.BindingException;
        import com.clover.sdk.v1.ClientException;
        import com.clover.sdk.v1.ServiceException;
        import com.clover.sdk.v3.inventory.InventoryConnector;
        import com.clover.sdk.v3.inventory.Item;

        import android.*;

public class FullscreenActivity extends AppCompatActivity {

    private Account mAccount;
    private InventoryConnector mInventoryConnector;
    private TextView mTextView;






    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Button searchButton = (Button) findViewById(R.id.searchButton);
        TextView searchContent = (TextView) findViewById(R.id.searchContent);
        searchButton.setText("");


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fullscreen);
    }

    @Override
    protected void onResume() {
        super.onResume();

        mTextView = (TextView) findViewById(R.id.searchContent);

        // Retrieve the Clover account
        if (mAccount == null) {
            mAccount = CloverAccount.getAccount(this);

            if (mAccount == null) {
                return;
            }
        }

        // Connect InventoryConnector
        connect();

        // Get Item
        new InventoryAsyncTask().execute();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        disconnect();
    }

    private void connect() {
        disconnect();
        if (mAccount != null) {
            mInventoryConnector = new InventoryConnector(this, mAccount, null);
            mInventoryConnector.connect();
        }
    }

    private void disconnect() {
        if (mInventoryConnector != null) {
            mInventoryConnector.disconnect();
            mInventoryConnector = null;
        }
    }

    private class InventoryAsyncTask extends AsyncTask<Void, Void, Item> {

        @Override
        protected final Item doInBackground(Void... params) {
            try {
                //Get inventory item
                return mInventoryConnector.getItems().get(0);

            } catch (RemoteException | ClientException | ServiceException | BindingException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected final void onPostExecute(Item item) {
            if (item != null) {
                mTextView.setText(item.getName());
            }
        }
    }
}